# p2
#button {
	padding: 1;
}
#button li {
	display: inline;
}